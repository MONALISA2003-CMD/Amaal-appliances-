# Amaal Master Price Register

Customer-facing policy: one current UGX master price per exact catalogue SKU. No crossed-out prices, artificial discounts or “was/now” pricing are exposed.

## Refrigerator additions in this build

| Brand | Model | Product | Master price (UGX) | Confidence | Image evidence |
|---|---|---|---:|---|---|
| LG | GL-C252SLBB | 234L Top Freezer Refrigerator | 1,630,000 | High | LG OEM + Uganda listing |
| Samsung | RT31CG5421S9UT | 305L Top Mount Refrigerator | 2,924,000 | High | Samsung OEM + Uganda listing |
| Midea | MDRT187 | 187L Double Door Top Mount Refrigerator | 786,000 | High | Midea/Jumia Uganda exact model |
| Roch | RFR-120S-J | 120L Single Door Refrigerator | 345,000 | High | Roch/Jumia Uganda exact model |
| ADH | BC8091 | 120L Single Door Refrigerator | 375,000 | High | ADH/Jumia Uganda exact model |

## Existing catalogue
The original 48 catalogue prices remain unchanged. See the Git history or previous master register for their research records.

## Pricing method
1. Identify the exact model/SKU.
2. Prefer multiple credible Uganda observations where available.
3. Use OEM information to verify model identity and specifications.
4. Normalize awkward retail values only when the evidence supports it.
5. Treat large discrepancies as a research task, not an automatic average.
6. Freeze the implementation price only after model identity and evidence quality are acceptable.

## Important implementation rule
The frontend `price` field is catalogue data, not the production payment authority. A future backend must re-read the authoritative SKU price before order creation.


## Freezers continuation
Freezers have been added as the next catalogue capability. Current implementation contains exact-model Uganda observations for Hisense, ADH, Midea, Roch and Beko, with Samsung/LG expansion still subject to clean exact-model image and evidence verification.

## Refrigeration price-quality correction — 7 September 2026
- Hisense FC13DT4ST master price normalized to UGX 546,000 using current Uganda official-store observations around UGX 545,500.
- Roch RCF-125G-E master price normalized to UGX 477,000 using current Uganda official-store observations around UGX 469,000–484,000.
- Midea MDRC265FZG43D master price recorded at UGX 800,000 as a medium-confidence local observation while the manufacturer confirms the model is 142L.
- Midea MDRC362FZG43D master price recorded at UGX 878,000 from the current Uganda Midea Official Store observation.

## Refrigerator continuation — 7 September 2026

| Brand | Model | Product | Master price (UGX) | Confidence | Image evidence |
|---|---|---|---:|---|---|
| LG | GN-B312PXGB | 315L Top Freezer Refrigerator | 2,315,000 | High | Clean exact-model Uganda Official Store image + LG East Africa OEM |
