import Link from 'next/link';
import type {Product} from '@/types/product';
import {formatUGX} from '@/lib/catalogue';
import {AddToCartButton} from '@/components/commerce/AddToCartButton';
import {ProductImage} from '@/components/catalogue/ProductImage';

export function ProductCard({product}:{product:Product}){
  return <article className="product-card">
    <Link href={`/product/${product.slug}`} className="product-media">
      {product.image ? <ProductImage
        src={product.image}
        alt={`${product.brand} ${product.model} product image`}
        width={520}
        height={420}
        sizes="(max-width: 720px) 50vw, (max-width: 1100px) 33vw, 260px"
        brand={product.brand}
        model={product.model}
        style={{width:'100%',height:'100%',objectFit:'contain',objectPosition:'center'}}
      /> : <div className="product-placeholder"><strong>{product.brand}</strong><span>{product.model}</span></div>}
    </Link>
    <div className="product-body">
      <div className="product-meta">
        <strong className="product-brand-name">{product.brand}</strong>
        <span>{product.category}</span>
      </div>
      <Link href={`/product/${product.slug}`} className="product-title">{product.name}</Link>
      <div className="model">Model {product.model}</div>
      <div className="price">{formatUGX(product.price)}</div>
      <div className="product-actions"><AddToCartButton product={product}/><Link className="btn secondary" href={`/product/${product.slug}`}>Details</Link></div>
    </div>
  </article>
}
